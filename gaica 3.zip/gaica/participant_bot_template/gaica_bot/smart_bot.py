from __future__ import annotations

from dataclasses import dataclass, field
import math

from gaica_bot.models import (
    BotCommand,
    BotState,
    HelloMessage,
    LetterboxView,
    ObstacleView,
    PickupView,
    PlayerView,
    ProjectileView,
    RoundEndMessage,
    RoundStartMessage,
    TickMessage,
    Vec2,
)


TILE_SIZE = 64.0
PLAYER_RADIUS = 10.0
PLAYER_SPEED = 255.0
WEAPON_PICKUP_DISTANCE = 25.0
KICK_RANGE = 28.0
KICK_ARC_DOT_THRESHOLD = 0.45
REVOLVER_COOLDOWN = 0.4
UZI_COOLDOWN = 0.1
REVOLVER_RANGE_MIN = 95.0
REVOLVER_RANGE_MAX = 255.0
UZI_RANGE_MIN = 30.0
UZI_RANGE_MAX = 150.0
FUTURE_STEP = PLAYER_SPEED / 30.0
EMERGENCY_BULLET_RISK = 1.15


def _v_add(a: Vec2, b: Vec2) -> Vec2:
    return Vec2(a.x + b.x, a.y + b.y)


def _v_sub(a: Vec2, b: Vec2) -> Vec2:
    return Vec2(a.x - b.x, a.y - b.y)


def _v_mul(a: Vec2, scalar: float) -> Vec2:
    return Vec2(a.x * scalar, a.y * scalar)


def _dot(a: Vec2, b: Vec2) -> float:
    return a.x * b.x + a.y * b.y


def _length(a: Vec2) -> float:
    return math.hypot(a.x, a.y)


def _normalize(a: Vec2) -> Vec2:
    mag = _length(a)
    if mag <= 1e-9:
        return Vec2()
    return Vec2(a.x / mag, a.y / mag)


def _distance(a: Vec2, b: Vec2) -> float:
    return math.hypot(a.x - b.x, a.y - b.y)


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def _perp_left(a: Vec2) -> Vec2:
    return Vec2(-a.y, a.x)


def _perp_right(a: Vec2) -> Vec2:
    return Vec2(a.y, -a.x)


def _distance_point_to_segment(point: Vec2, start: Vec2, end: Vec2) -> float:
    segment = _v_sub(end, start)
    seg_len_sq = _dot(segment, segment)
    if seg_len_sq <= 1e-9:
        return _distance(point, start)
    t = _clamp(_dot(_v_sub(point, start), segment) / seg_len_sq, 0.0, 1.0)
    closest = _v_add(start, _v_mul(segment, t))
    return _distance(point, closest)


def _ray_segment_aabb_intersection(start: Vec2, end: Vec2, rect: ObstacleView) -> float | None:
    direction = _v_sub(end, start)

    min_x = rect.center.x - rect.half_size.x
    max_x = rect.center.x + rect.half_size.x
    min_y = rect.center.y - rect.half_size.y
    max_y = rect.center.y + rect.half_size.y

    t_min = 0.0
    t_max = 1.0

    for axis in ("x", "y"):
        origin = start.x if axis == "x" else start.y
        axis_dir = direction.x if axis == "x" else direction.y
        slab_min = min_x if axis == "x" else min_y
        slab_max = max_x if axis == "x" else max_y

        if abs(axis_dir) < 1e-9:
            if origin < slab_min or origin > slab_max:
                return None
            continue

        inv = 1.0 / axis_dir
        t1 = (slab_min - origin) * inv
        t2 = (slab_max - origin) * inv
        if t1 > t2:
            t1, t2 = t2, t1
        t_min = max(t_min, t1)
        t_max = min(t_max, t2)
        if t_min > t_max:
            return None

    if 0.0 <= t_min <= 1.0:
        return t_min
    if 0.0 <= t_max <= 1.0:
        return t_max
    return None


@dataclass
class CandidateMove:
    direction: Vec2
    score: float


@dataclass
class SmartBot:
    state: BotState = field(default_factory=BotState)
    floor_cells: set[tuple[int, int]] = field(default_factory=set)
    last_enemy_position: Vec2 | None = None
    last_my_position: Vec2 | None = None
    tick_dt: float = 1.0 / 30.0

    def on_hello(self, message: HelloMessage) -> None:
        self.state.hello = message
        self.tick_dt = 1.0 / max(1, message.tick_rate)

    def on_round_start(self, message: RoundStartMessage) -> None:
        self.state.current_round = message
        self.state.last_tick = None
        self.state.last_round_end = None
        self.floor_cells = {
            (int(tile.get("x", 0) // TILE_SIZE), int(tile.get("y", 0) // TILE_SIZE))
            for tile in message.level.floor_tiles
            if isinstance(tile, dict)
        }
        self.last_enemy_position = None
        self.last_my_position = None
        self.tick_dt = 1.0 / max(1, message.tick_rate)

    def on_round_end(self, message: RoundEndMessage) -> None:
        self.state.last_round_end = message

    def on_tick(self, message: TickMessage) -> BotCommand:
        self.state.last_tick = message
        seq = self.state.next_command_seq()

        me = message.you
        enemy = message.enemy
        if not me.alive:
            return BotCommand(seq=seq)

        enemy_velocity = self._estimate_velocity(self.last_enemy_position, enemy.position)
        best_pickup = self._best_pickup(message, me, enemy)
        best_mailbox = self._best_mailbox(message, me, enemy)
        move = Vec2()
        aim = self._combat_aim(me, enemy, enemy_velocity)
        shoot = False
        pickup = False
        kick = False

        bullet_risk_now = self._bullet_risk(
            message.snapshot.projectiles,
            me.position,
            me.position,
            ignored_owner_id=me.player_id,
        )
        if bullet_risk_now >= EMERGENCY_BULLET_RISK:
            move = self._emergency_dodge(message, me, enemy, best_pickup, best_mailbox)
            aim = self._combat_aim(me, enemy, enemy_velocity)
        elif self._can_kick(me, enemy):
            kick = True
            aim = _normalize(_v_sub(enemy.position, me.position))
            move = self._safe_step(message, me, aim)
        else:
            move = self._choose_positioning_move(message, me, enemy, best_pickup, best_mailbox)

            if self._should_pickup_now(me, enemy, best_pickup):
                pickup = True
                aim = _normalize(_v_sub(best_pickup.position, me.position))
            elif self._should_kick_mailbox(me, best_mailbox):
                kick = True
                aim = _normalize(_v_sub(best_mailbox.position, me.position))
            else:
                predicted_pos = _v_add(me.position, _v_mul(move, FUTURE_STEP))
                shoot = self._should_shoot(message, me, enemy, enemy_velocity, predicted_pos)
                if not shoot and self._should_break_glass(message, me, enemy, predicted_pos):
                    shoot = True

        self.last_enemy_position = Vec2(enemy.position.x, enemy.position.y)
        self.last_my_position = Vec2(me.position.x, me.position.y)
        return BotCommand(
            seq=seq,
            move=move,
            aim=aim if _length(aim) > 1e-6 else Vec2(1.0, 0.0),
            shoot=shoot,
            kick=kick,
            pickup=pickup,
        )

    def _estimate_velocity(self, previous: Vec2 | None, current: Vec2) -> Vec2:
        if previous is None:
            return Vec2()
        return Vec2((current.x - previous.x) / self.tick_dt, (current.y - previous.y) / self.tick_dt)

    def _combat_aim(self, me: PlayerView, enemy: PlayerView, enemy_velocity: Vec2) -> Vec2:
        to_enemy = _v_sub(enemy.position, me.position)
        distance = _length(to_enemy)
        if distance <= 1e-6:
            return Vec2(1.0, 0.0)
        lead_time = min(0.22, distance / 500.0)
        predicted = _v_add(enemy.position, _v_mul(enemy_velocity, lead_time))
        return _normalize(_v_sub(predicted, me.position))

    def _weapon_name(self, player: PlayerView) -> str:
        if player.weapon is None:
            return "none"
        return player.weapon.weapon_type.lower()

    def _has_weapon(self, player: PlayerView) -> bool:
        return player.weapon is not None and player.weapon.ammo > 0

    def _preferred_distance_score(self, player: PlayerView, distance: float) -> float:
        weapon = self._weapon_name(player)
        if weapon == "revolver":
            if distance < 70.0:
                return -1.8
            if REVOLVER_RANGE_MIN <= distance <= REVOLVER_RANGE_MAX:
                return 2.0
            if distance <= 310.0:
                return 0.7
            return -0.4
        if weapon == "uzi":
            if UZI_RANGE_MIN <= distance <= UZI_RANGE_MAX:
                return 2.2
            if distance <= 190.0:
                return 0.6
            return -1.2
        return -0.2

    def _first_blocker(self, start: Vec2, end: Vec2, obstacles: list[ObstacleView]) -> ObstacleView | None:
        best_t: float | None = None
        blocker: ObstacleView | None = None
        for obstacle in obstacles:
            if not obstacle.solid:
                continue
            hit_t = _ray_segment_aabb_intersection(start, end, obstacle)
            if hit_t is None:
                continue
            if best_t is None or hit_t < best_t:
                best_t = hit_t
                blocker = obstacle
        return blocker

    def _clear_line(self, start: Vec2, end: Vec2, obstacles: list[ObstacleView]) -> bool:
        return self._first_blocker(start, end, obstacles) is None

    def _projectile_threat(self, projectile: ProjectileView, current_pos: Vec2, future_pos: Vec2) -> float:
        if projectile.owner_id == 0:
            return 0.0
        velocity_mag = max(1e-6, _length(projectile.velocity))
        horizon = min(0.35, projectile.remaining_life)
        future_bullet = _v_add(projectile.position, _v_mul(projectile.velocity, horizon))
        if _dot(_v_sub(current_pos, projectile.position), projectile.velocity) < -10.0:
            return 0.0

        distance_now = _distance_point_to_segment(current_pos, projectile.position, future_bullet)
        distance_future = _distance_point_to_segment(future_pos, projectile.position, future_bullet)
        closest = min(distance_now, distance_future)
        if closest > PLAYER_RADIUS + 14.0:
            return 0.0

        direction_to_me = _v_sub(current_pos, projectile.position)
        time_to_reach = _dot(direction_to_me, projectile.velocity) / (velocity_mag * velocity_mag)
        if time_to_reach < -0.05 or time_to_reach > horizon + 0.05:
            return 0.0

        return 2.5 - 0.12 * closest

    def _bullet_risk(
        self,
        projectiles: list[ProjectileView],
        current_pos: Vec2,
        future_pos: Vec2,
        ignored_owner_id: int,
    ) -> float:
        risk = 0.0
        for projectile in projectiles:
            if projectile.owner_id == ignored_owner_id:
                continue
            risk += self._projectile_threat(projectile, current_pos, future_pos)
        return risk

    def _is_grounded(self, position: Vec2) -> bool:
        return (int(position.x // TILE_SIZE), int(position.y // TILE_SIZE)) in self.floor_cells

    def _edge_risk(self, position: Vec2, move_dir: Vec2) -> float:
        if not self._is_grounded(position):
            return 1000.0
        next_position = _v_add(position, _v_mul(move_dir, FUTURE_STEP * 1.7))
        if not self._is_grounded(next_position):
            return 8.0
        cell_x = int(position.x // TILE_SIZE)
        cell_y = int(position.y // TILE_SIZE)
        open_neighbors = 0
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            if (cell_x + dx, cell_y + dy) in self.floor_cells:
                open_neighbors += 1
        if open_neighbors <= 1:
            return 2.4
        if open_neighbors == 2:
            return 1.1
        return 0.0

    def _enemy_fire_risk(self, obstacles: list[ObstacleView], enemy: PlayerView, future_pos: Vec2) -> float:
        if not enemy.alive or not self._has_weapon(enemy):
            return 0.0
        if not self._clear_line(enemy.position, future_pos, obstacles):
            return 0.0
        to_target = _normalize(_v_sub(future_pos, enemy.position))
        facing = enemy.facing.normalized() if enemy.facing.length() > 1e-6 else to_target
        alignment = _dot(facing, to_target)
        distance = _distance(enemy.position, future_pos)
        risk = 1.6 + max(0.0, alignment)
        if self._weapon_name(enemy) == "uzi" and distance < 150.0:
            risk += 0.8
        if self._weapon_name(enemy) == "revolver" and distance < 260.0:
            risk += 0.5
        if enemy.shoot_cooldown > 0.15:
            risk *= 0.55
        return risk

    def _cover_quality(self, obstacles: list[ObstacleView], enemy: PlayerView, future_pos: Vec2) -> float:
        return 1.8 if not self._clear_line(enemy.position, future_pos, obstacles) else 0.0

    def _best_pickup(self, message: TickMessage, me: PlayerView, enemy: PlayerView) -> PickupView | None:
        best: PickupView | None = None
        best_score = -1e9
        for pickup in message.snapshot.pickups:
            if pickup.cooldown > 0.0:
                continue
            my_dist = _distance(me.position, pickup.position)
            enemy_dist = _distance(enemy.position, pickup.position)
            value = 8.0 if pickup.weapon_type.lower() == "uzi" else 6.0
            score = value - 0.04 * my_dist + 0.02 * enemy_dist
            if not self._is_grounded(pickup.position):
                score -= 5.0
            if score > best_score:
                best_score = score
                best = pickup
        return best

    def _best_mailbox(self, message: TickMessage, me: PlayerView, enemy: PlayerView) -> LetterboxView | None:
        best: LetterboxView | None = None
        best_score = -1e9
        for mailbox in message.snapshot.letterboxes:
            if not mailbox.ready:
                continue
            my_dist = _distance(me.position, mailbox.position)
            enemy_dist = _distance(enemy.position, mailbox.position)
            score = 7.5 - 0.035 * my_dist + 0.015 * enemy_dist
            if score > best_score:
                best_score = score
                best = mailbox
        return best

    def _safe_step(self, message: TickMessage, me: PlayerView, desired: Vec2) -> Vec2:
        desired = _normalize(desired)
        future = _v_add(me.position, _v_mul(desired, FUTURE_STEP))
        if self._is_grounded(future):
            return desired
        left = _normalize(_perp_left(desired))
        right = _normalize(_perp_right(desired))
        for option in (left, right, Vec2()):
            future = _v_add(me.position, _v_mul(option, FUTURE_STEP))
            if self._is_grounded(future):
                return option
        return Vec2()

    def _can_kick(self, me: PlayerView, enemy: PlayerView) -> bool:
        if me.kick_cooldown > 0.0 or not enemy.alive:
            return False
        to_enemy = _v_sub(enemy.position, me.position)
        distance = _length(to_enemy)
        if distance <= 1e-6 or distance > KICK_RANGE:
            return False
        aim = _normalize(to_enemy)
        return _dot(aim, _normalize(to_enemy)) >= KICK_ARC_DOT_THRESHOLD

    def _should_pickup_now(self, me: PlayerView, enemy: PlayerView, pickup: PickupView | None) -> bool:
        if pickup is None:
            return False
        if _distance(me.position, pickup.position) > WEAPON_PICKUP_DISTANCE:
            return False
        if self._has_weapon(me):
            current_weapon = self._weapon_name(me)
            current_ammo = me.weapon.ammo if me.weapon is not None else 0
            next_weapon = pickup.weapon_type.lower()
            if current_ammo > 2 and current_weapon == "uzi":
                return False
            if current_ammo > 5 and current_weapon == "revolver" and next_weapon != "uzi":
                return False
        enemy_close = _distance(enemy.position, pickup.position) < 38.0
        return not enemy_close or self._has_weapon(me)

    def _should_kick_mailbox(self, me: PlayerView, mailbox: LetterboxView | None) -> bool:
        if mailbox is None or me.kick_cooldown > 0.0:
            return False
        if self._has_weapon(me):
            return False
        return _distance(me.position, mailbox.position) <= 24.0

    def _should_shoot(
        self,
        message: TickMessage,
        me: PlayerView,
        enemy: PlayerView,
        enemy_velocity: Vec2,
        future_pos: Vec2,
    ) -> bool:
        if not enemy.alive or not self._has_weapon(me):
            return False
        if me.shoot_cooldown > 0.0:
            return False

        aim_target = _v_add(enemy.position, _v_mul(enemy_velocity, min(0.2, _distance(me.position, enemy.position) / 500.0)))
        blocker = self._first_blocker(future_pos, aim_target, message.snapshot.obstacles)
        if blocker is not None:
            return False

        distance = _distance(future_pos, enemy.position)
        preferred = self._preferred_distance_score(me, distance)
        risk = self._bullet_risk(
            message.snapshot.projectiles,
            me.position,
            future_pos,
            ignored_owner_id=me.player_id,
        )
        if preferred < -0.6:
            return False
        if risk > 1.25 and enemy.stun_remaining <= 0.0:
            return False

        if self._weapon_name(me) == "uzi":
            return distance <= 180.0
        return distance <= 300.0

    def _should_break_glass(self, message: TickMessage, me: PlayerView, enemy: PlayerView, future_pos: Vec2) -> bool:
        if not self._has_weapon(me) or me.shoot_cooldown > 0.0:
            return False
        if self._weapon_name(me) != "revolver":
            return False
        blocker = self._first_blocker(future_pos, enemy.position, message.snapshot.obstacles)
        if blocker is None or blocker.kind != "glass":
            return False
        if self._bullet_risk(
            message.snapshot.projectiles,
            me.position,
            future_pos,
            ignored_owner_id=me.player_id,
        ) > 1.0:
            return False
        distance = _distance(future_pos, enemy.position)
        return distance <= 240.0

    def _series_risk_bias(self) -> float:
        current_round = self.state.current_round
        if current_round is None or not current_round.series.enabled:
            return 1.0
        my_key = str(current_round.player_id)
        enemy_key = str(current_round.enemy_id)
        my_score = current_round.series.score.get(my_key, 0)
        enemy_score = current_round.series.score.get(enemy_key, 0)
        if my_score > enemy_score:
            return 1.25
        if my_score < enemy_score:
            return 0.82
        return 1.0

    def _choose_positioning_move(
        self,
        message: TickMessage,
        me: PlayerView,
        enemy: PlayerView,
        pickup: PickupView | None,
        mailbox: LetterboxView | None,
    ) -> Vec2:
        to_enemy = _normalize(_v_sub(enemy.position, me.position))
        left = _normalize(_perp_left(to_enemy))
        right = _normalize(_perp_right(to_enemy))
        toward_pickup = _normalize(_v_sub(pickup.position, me.position)) if pickup is not None else Vec2()
        toward_mailbox = _normalize(_v_sub(mailbox.position, me.position)) if mailbox is not None else Vec2()

        candidates = [
            Vec2(),
            to_enemy,
            _v_mul(to_enemy, -1.0),
            left,
            right,
            _normalize(_v_add(to_enemy, left)),
            _normalize(_v_add(to_enemy, right)),
            _normalize(_v_sub(left, to_enemy)),
            _normalize(_v_sub(right, to_enemy)),
            toward_pickup,
            toward_mailbox,
        ]

        best = CandidateMove(direction=Vec2(), score=-1e9)
        for candidate in candidates:
            if _length(candidate) > 1e-6:
                candidate = _normalize(candidate)
            score = self._score_move(message, me, enemy, pickup, mailbox, candidate)
            if score > best.score:
                best = CandidateMove(direction=candidate, score=score)
        return best.direction

    def _score_move(
        self,
        message: TickMessage,
        me: PlayerView,
        enemy: PlayerView,
        pickup: PickupView | None,
        mailbox: LetterboxView | None,
        move_dir: Vec2,
    ) -> float:
        future_pos = _v_add(me.position, _v_mul(move_dir, FUTURE_STEP))
        if not self._is_grounded(future_pos):
            return -1e8

        distance = _distance(future_pos, enemy.position)
        risk_bias = self._series_risk_bias()
        bullet_risk = self._bullet_risk(
            message.snapshot.projectiles,
            me.position,
            future_pos,
            ignored_owner_id=me.player_id,
        )
        edge_risk = self._edge_risk(future_pos, move_dir)
        enemy_kick_risk = 2.6 if enemy.kick_cooldown <= 0.0 and distance < 34.0 else 0.0
        exposure = self._enemy_fire_risk(message.snapshot.obstacles, enemy, future_pos)
        cover = self._cover_quality(message.snapshot.obstacles, enemy, future_pos)
        shot_quality = 0.0
        if self._has_weapon(me) and self._clear_line(future_pos, enemy.position, message.snapshot.obstacles):
            shot_quality = self._preferred_distance_score(me, distance)
            if enemy.stun_remaining > 0.0:
                shot_quality += 1.3

        weapon_advantage = 0.0
        if self._has_weapon(me) and not self._has_weapon(enemy):
            weapon_advantage += 3.0
        elif not self._has_weapon(me) and self._has_weapon(enemy):
            weapon_advantage -= 3.6
        else:
            weapon_advantage += 0.7 * self._preferred_distance_score(me, distance)
            weapon_advantage -= 0.5 * self._preferred_distance_score(enemy, distance)

        pickup_value = 0.0
        if pickup is not None:
            my_eta = _distance(future_pos, pickup.position)
            enemy_eta = _distance(enemy.position, pickup.position)
            if not self._has_weapon(me):
                pickup_value += 4.0 - 0.03 * my_eta + 0.015 * enemy_eta
            elif me.weapon is not None and me.weapon.ammo <= 2:
                pickup_value += 1.2 - 0.02 * my_eta

        mailbox_value = 0.0
        if mailbox is not None and not self._has_weapon(me):
            mailbox_value += 3.0 - 0.022 * _distance(future_pos, mailbox.position)

        denial = 0.0
        if pickup is not None and _distance(future_pos, pickup.position) < _distance(enemy.position, pickup.position):
            denial += 0.8

        return (
            4.0 * shot_quality
            + 2.4 * cover
            + 2.3 * weapon_advantage
            + 1.9 * pickup_value
            + 1.2 * mailbox_value
            + 0.9 * denial
            - risk_bias * 5.7 * bullet_risk
            - risk_bias * 4.8 * edge_risk
            - risk_bias * 3.1 * enemy_kick_risk
            - risk_bias * 1.6 * exposure
        )

    def _emergency_dodge(
        self,
        message: TickMessage,
        me: PlayerView,
        enemy: PlayerView,
        pickup: PickupView | None,
        mailbox: LetterboxView | None,
    ) -> Vec2:
        escape_axes: list[Vec2] = [Vec2()]
        for projectile in message.snapshot.projectiles:
            away = _normalize(_perp_left(projectile.velocity))
            if _length(away) <= 1e-6:
                continue
            escape_axes.extend([away, _v_mul(away, -1.0)])

        to_enemy = _normalize(_v_sub(enemy.position, me.position))
        escape_axes.extend([_perp_left(to_enemy), _perp_right(to_enemy), _v_mul(to_enemy, -1.0)])
        if pickup is not None:
            escape_axes.append(_normalize(_v_sub(pickup.position, me.position)))
        if mailbox is not None:
            escape_axes.append(_normalize(_v_sub(mailbox.position, me.position)))

        best = CandidateMove(direction=Vec2(), score=-1e9)
        for direction in escape_axes:
            if _length(direction) > 1e-6:
                direction = _normalize(direction)
            future_pos = _v_add(me.position, _v_mul(direction, FUTURE_STEP))
            if not self._is_grounded(future_pos):
                continue
            score = -6.0 * self._bullet_risk(
                message.snapshot.projectiles,
                me.position,
                future_pos,
                ignored_owner_id=me.player_id,
            )
            score -= 4.0 * self._edge_risk(future_pos, direction)
            score -= 1.5 * self._enemy_fire_risk(message.snapshot.obstacles, enemy, future_pos)
            score += 1.2 * self._cover_quality(message.snapshot.obstacles, enemy, future_pos)
            if score > best.score:
                best = CandidateMove(direction=direction, score=score)
        return best.direction
